package com.example.localite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    EditText name , password;
    Button login;
    TextView newUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText)findViewById(R.id.name);
        password = (EditText)findViewById(R.id.password);
        login = (Button)findViewById(R.id.login);
        newUser  = (TextView)findViewById(R.id.newuser);

        getSupportActionBar((Toolbar) findViewById(R.id.toolbar));

        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Toast.makeText(MainActivity.this , "Clickable" , Toast.LENGTH_LONG).show();

                ConsumerOrProvider cp = new ConsumerOrProvider();

                cp.show(getSupportFragmentManager() , "123");

            }
        });
    }

    public void getType(String s){

        if (s.equals("Consumer")){
            Intent intent = new Intent(this , ConsumerSignIn.class);
            startActivity(intent);
        }else{
            Intent intent = new Intent(this , ProviderSignIn.class);
            startActivity(intent);
        }

    }
}
