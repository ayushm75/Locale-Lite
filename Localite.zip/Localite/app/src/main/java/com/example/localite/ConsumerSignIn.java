package com.example.localite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ConsumerSignIn extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumer_sign_in);
    }
}
